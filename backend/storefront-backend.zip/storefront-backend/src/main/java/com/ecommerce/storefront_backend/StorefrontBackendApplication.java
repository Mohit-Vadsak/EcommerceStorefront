package com.ecommerce.storefront_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StorefrontBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(StorefrontBackendApplication.class, args);
	}

}
